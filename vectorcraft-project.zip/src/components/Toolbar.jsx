import { MousePointer, Square, Circle, Pen, Type, Move, Hand } from 'lucide-react';
import './Toolbar.css';

function Toolbar({ activeTool, setActiveTool }) {
    const tools = [
        { id: 'select', icon: <MousePointer size={20} />, label: 'Select' },
        { id: 'hand', icon: <Hand size={20} />, label: 'Pan' },
        { id: 'rectangle', icon: <Square size={20} />, label: 'Rectangle' },
        { id: 'circle', icon: <Circle size={20} />, label: 'Circle' },
        { id: 'pen', icon: <Pen size={20} />, label: 'Pen Tool' },
        { id: 'text', icon: <Type size={20} />, label: 'Text' },
        { id: 'move', icon: <Move size={20} />, label: 'Move' },
    ];

    return (
        <div className="toolbar glass slide-in-left">
            <div className="toolbar-header">
                <h3>Tools</h3>
            </div>

            <div className="toolbar-tools">
                {tools.map((tool, index) => (
                    <button
                        key={tool.id}
                        className={`tool-btn ${activeTool === tool.id ? 'active' : ''}`}
                        onClick={() => setActiveTool(tool.id)}
                        data-tooltip={tool.label}
                        style={{ animationDelay: `${index * 0.05}s` }}
                    >
                        {tool.icon}
                        <span className="tool-label">{tool.label}</span>
                    </button>
                ))}
            </div>

            <div className="toolbar-footer">
                <div className="color-quick-select">
                    <div className="color-label">Fill</div>
                    <div className="color-swatches">
                        <div className="color-swatch" style={{ background: '#667eea' }}></div>
                        <div className="color-swatch" style={{ background: '#f5576c' }}></div>
                        <div className="color-swatch" style={{ background: '#43e97b' }}></div>
                        <div className="color-swatch" style={{ background: '#4facfe' }}></div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Toolbar;
