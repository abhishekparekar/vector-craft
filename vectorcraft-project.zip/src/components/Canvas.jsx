import { useEffect, useRef } from 'react';
import paper from 'paper';
import './Canvas.css';

function Canvas({ activeTool, setSelectedObject, setLayers, setCanvasRef, gridEnabled, zoom, setZoom }) {
    const canvasRef = useRef(null);
    const toolRef = useRef(null);
    const currentPathRef = useRef(null);

    useEffect(() => {
        if (!canvasRef.current) return;

        // Setup Paper.js
        paper.setup(canvasRef.current);
        setCanvasRef(paper);

        // Create grid
        const grid = createGrid();
        grid.visible = gridEnabled;

        // Pan and zoom setup
        let isPanning = false;
        let lastPoint = null;

        paper.view.onMouseDown = (event) => {
            if (activeTool === 'hand' || event.modifiers.space) {
                isPanning = true;
                lastPoint = event.point;
                return;
            }
        };

        paper.view.onMouseDrag = (event) => {
            if (isPanning) {
                const delta = event.point.subtract(lastPoint);
                paper.view.center = paper.view.center.subtract(delta);
                lastPoint = event.point;
                return;
            }
        };

        paper.view.onMouseUp = () => {
            isPanning = false;
            lastPoint = null;
        };

        // Zoom with mouse wheel
        paper.view.onMouseWheel = (event) => {
            event.preventDefault();
            const delta = event.deltaY;
            const factor = delta > 0 ? 0.9 : 1.1;
            const newZoom = paper.view.zoom * factor;

            if (newZoom > 0.1 && newZoom < 10) {
                paper.view.zoom = newZoom;
                setZoom(newZoom);
            }
        };

        return () => {
            paper.project?.clear();
        };
    }, []);

    useEffect(() => {
        if (!paper.project) return;

        // Update grid visibility
        const grid = paper.project.getItem({ name: 'grid' });
        if (grid) {
            grid.visible = gridEnabled;
        }
    }, [gridEnabled]);

    useEffect(() => {
        if (!paper.project) return;

        // Remove previous tool
        if (toolRef.current) {
            toolRef.current.remove();
        }

        // Create new tool based on active tool
        const tool = new paper.Tool();
        toolRef.current = tool;

        switch (activeTool) {
            case 'select':
                setupSelectTool(tool, setSelectedObject);
                break;
            case 'rectangle':
                setupRectangleTool(tool, setLayers);
                break;
            case 'circle':
                setupCircleTool(tool, setLayers);
                break;
            case 'pen':
                setupPenTool(tool, currentPathRef, setLayers);
                break;
            case 'text':
                setupTextTool(tool, setLayers);
                break;
            default:
                break;
        }

        tool.activate();
    }, [activeTool]);

    const createGrid = () => {
        const grid = new paper.Group();
        grid.name = 'grid';

        const gridSize = 20;
        const bounds = paper.view.bounds;

        for (let x = bounds.left; x < bounds.right; x += gridSize) {
            const line = new paper.Path.Line({
                from: [x, bounds.top],
                to: [x, bounds.bottom],
                strokeColor: new paper.Color(1, 1, 1, 0.05),
                strokeWidth: 1
            });
            grid.addChild(line);
        }

        for (let y = bounds.top; y < bounds.bottom; y += gridSize) {
            const line = new paper.Path.Line({
                from: [bounds.left, y],
                to: [bounds.right, y],
                strokeColor: new paper.Color(1, 1, 1, 0.05),
                strokeWidth: 1
            });
            grid.addChild(line);
        }

        return grid;
    };

    return (
        <div className="canvas-container">
            <canvas ref={canvasRef} className="main-canvas" resize="true"></canvas>

            {/* Canvas overlay info */}
            <div className="canvas-overlay">
                <div className="canvas-info glass">
                    <span>Tool: <strong>{activeTool}</strong></span>
                    <span>Zoom: <strong>{Math.round(zoom * 100)}%</strong></span>
                </div>
            </div>
        </div>
    );
}

// ==================== TOOL IMPLEMENTATIONS ====================

function setupSelectTool(tool, setSelectedObject) {
    let selectedItem = null;

    tool.onMouseDown = (event) => {
        const hitResult = paper.project.hitTest(event.point, {
            fill: true,
            stroke: true,
            tolerance: 5
        });

        if (hitResult && hitResult.item.name !== 'grid') {
            selectedItem = hitResult.item;
            setSelectedObject(selectedItem);
            selectedItem.selected = true;
        } else {
            if (selectedItem) {
                selectedItem.selected = false;
            }
            selectedItem = null;
            setSelectedObject(null);
        }
    };

    tool.onMouseDrag = (event) => {
        if (selectedItem) {
            selectedItem.position = selectedItem.position.add(event.delta);
        }
    };
}

function setupRectangleTool(tool, setLayers) {
    let path;

    tool.onMouseDown = (event) => {
        path = new paper.Path.Rectangle({
            from: event.point,
            to: event.point.add([1, 1]),
            fillColor: new paper.Color('#667eea'),
            strokeColor: new paper.Color('#764ba2'),
            strokeWidth: 2,
            name: 'rectangle'
        });
    };

    tool.onMouseDrag = (event) => {
        if (path) {
            path.remove();
            path = new paper.Path.Rectangle({
                from: event.downPoint,
                to: event.point,
                fillColor: new paper.Color('#667eea'),
                strokeColor: new paper.Color('#764ba2'),
                strokeWidth: 2,
                name: 'rectangle'
            });
        }
    };

    tool.onMouseUp = () => {
        if (path) {
            updateLayers(setLayers);
        }
    };
}

function setupCircleTool(tool, setLayers) {
    let path;

    tool.onMouseDown = (event) => {
        path = new paper.Path.Circle({
            center: event.point,
            radius: 1,
            fillColor: new paper.Color('#f5576c'),
            strokeColor: new paper.Color('#f093fb'),
            strokeWidth: 2,
            name: 'circle'
        });
    };

    tool.onMouseDrag = (event) => {
        if (path) {
            const radius = event.point.subtract(event.downPoint).length;
            path.remove();
            path = new paper.Path.Circle({
                center: event.downPoint,
                radius: radius,
                fillColor: new paper.Color('#f5576c'),
                strokeColor: new paper.Color('#f093fb'),
                strokeWidth: 2,
                name: 'circle'
            });
        }
    };

    tool.onMouseUp = () => {
        if (path) {
            updateLayers(setLayers);
        }
    };
}

function setupPenTool(tool, currentPathRef, setLayers) {
    tool.onMouseDown = (event) => {
        currentPathRef.current = new paper.Path({
            strokeColor: new paper.Color('#4facfe'),
            strokeWidth: 3,
            strokeCap: 'round',
            strokeJoin: 'round',
            name: 'path'
        });
        currentPathRef.current.add(event.point);
    };

    tool.onMouseDrag = (event) => {
        if (currentPathRef.current) {
            currentPathRef.current.add(event.point);
        }
    };

    tool.onMouseUp = () => {
        if (currentPathRef.current) {
            currentPathRef.current.simplify(10);
            updateLayers(setLayers);
        }
    };
}

function setupTextTool(tool, setLayers) {
    tool.onMouseDown = (event) => {
        const text = new paper.PointText({
            point: event.point,
            content: 'Edit me...',
            fillColor: new paper.Color('white'),
            fontFamily: 'Inter, sans-serif',
            fontSize: 32,
            name: 'text'
        });
        updateLayers(setLayers);
    };
}

function updateLayers(setLayers) {
    const items = paper.project.activeLayer.children
        .filter(item => item.name && item.name !== 'grid')
        .map((item, index) => ({
            id: item.id,
            name: item.name || `Layer ${index + 1}`,
            visible: item.visible,
            type: item.name
        }));
    setLayers(items);
}

export default Canvas;
