import { Palette, Sliders } from 'lucide-react';
import { useState, useEffect } from 'react';
import './PropertiesPanel.css';

function PropertiesPanel({ selectedObject, canvasRef }) {
    const [fillColor, setFillColor] = useState('#667eea');
    const [strokeColor, setStrokeColor] = useState('#764ba2');
    const [strokeWidth, setStrokeWidth] = useState(2);
    const [opacity, setOpacity] = useState(1);
    const [rotation, setRotation] = useState(0);
    const [scaleX, setScaleX] = useState(1);
    const [scaleY, setScaleY] = useState(1);

    useEffect(() => {
        if (selectedObject) {
            if (selectedObject.fillColor) {
                setFillColor(selectedObject.fillColor.toCSS(true));
            }
            if (selectedObject.strokeColor) {
                setStrokeColor(selectedObject.strokeColor.toCSS(true));
            }
            if (selectedObject.strokeWidth) {
                setStrokeWidth(selectedObject.strokeWidth);
            }
            if (selectedObject.opacity !== undefined) {
                setOpacity(selectedObject.opacity);
            }
            if (selectedObject.rotation !== undefined) {
                setRotation(selectedObject.rotation);
            }
        }
    }, [selectedObject]);

    const handleFillColorChange = (color) => {
        setFillColor(color);
        if (selectedObject && canvasRef) {
            selectedObject.fillColor = color;
        }
    };

    const handleStrokeColorChange = (color) => {
        setStrokeColor(color);
        if (selectedObject && canvasRef) {
            selectedObject.strokeColor = color;
        }
    };

    const handleStrokeWidthChange = (width) => {
        setStrokeWidth(width);
        if (selectedObject && canvasRef) {
            selectedObject.strokeWidth = parseFloat(width);
        }
    };

    const handleOpacityChange = (value) => {
        setOpacity(value);
        if (selectedObject && canvasRef) {
            selectedObject.opacity = parseFloat(value);
        }
    };

    const handleRotationChange = (value) => {
        const newRotation = parseFloat(value);
        if (selectedObject && canvasRef) {
            const delta = newRotation - rotation;
            selectedObject.rotate(delta);
            setRotation(newRotation);
        }
    };

    const handleScaleChange = (axis, value) => {
        const scale = parseFloat(value);
        if (selectedObject && canvasRef) {
            if (axis === 'x') {
                selectedObject.scale(scale / scaleX, 1);
                setScaleX(scale);
            } else {
                selectedObject.scale(1, scale / scaleY);
                setScaleY(scale);
            }
        }
    };

    return (
        <div className="properties-panel glass slide-in-right">
            <div className="panel-header">
                <Sliders size={18} />
                <h3>Properties</h3>
            </div>

            {!selectedObject ? (
                <div className="empty-state">
                    <Palette size={48} opacity={0.3} />
                    <p>Select an object to edit properties</p>
                </div>
            ) : (
                <div className="properties-content">
                    {/* Fill Color */}
                    <div className="property-group">
                        <label className="property-label">Fill Color</label>
                        <div className="color-input-group">
                            <input
                                type="color"
                                value={fillColor}
                                onChange={(e) => handleFillColorChange(e.target.value)}
                                className="color-picker"
                            />
                            <input
                                type="text"
                                value={fillColor}
                                onChange={(e) => handleFillColorChange(e.target.value)}
                                className="color-text"
                            />
                        </div>
                    </div>

                    {/* Stroke Color */}
                    <div className="property-group">
                        <label className="property-label">Stroke Color</label>
                        <div className="color-input-group">
                            <input
                                type="color"
                                value={strokeColor}
                                onChange={(e) => handleStrokeColorChange(e.target.value)}
                                className="color-picker"
                            />
                            <input
                                type="text"
                                value={strokeColor}
                                onChange={(e) => handleStrokeColorChange(e.target.value)}
                                className="color-text"
                            />
                        </div>
                    </div>

                    {/* Stroke Width */}
                    <div className="property-group">
                        <label className="property-label">
                            Stroke Width
                            <span className="property-value">{strokeWidth}px</span>
                        </label>
                        <input
                            type="range"
                            min="0"
                            max="20"
                            step="0.5"
                            value={strokeWidth}
                            onChange={(e) => handleStrokeWidthChange(e.target.value)}
                            className="range-slider"
                        />
                    </div>

                    {/* Opacity */}
                    <div className="property-group">
                        <label className="property-label">
                            Opacity
                            <span className="property-value">{Math.round(opacity * 100)}%</span>
                        </label>
                        <input
                            type="range"
                            min="0"
                            max="1"
                            step="0.01"
                            value={opacity}
                            onChange={(e) => handleOpacityChange(e.target.value)}
                            className="range-slider"
                        />
                    </div>

                    {/* Rotation */}
                    <div className="property-group">
                        <label className="property-label">
                            Rotation
                            <span className="property-value">{Math.round(rotation)}°</span>
                        </label>
                        <input
                            type="range"
                            min="0"
                            max="360"
                            value={rotation}
                            onChange={(e) => handleRotationChange(e.target.value)}
                            className="range-slider"
                        />
                    </div>

                    {/* Scale */}
                    <div className="property-group">
                        <label className="property-label">Scale</label>
                        <div className="dual-input">
                            <div className="input-with-label">
                                <span>X</span>
                                <input
                                    type="number"
                                    min="0.1"
                                    max="5"
                                    step="0.1"
                                    value={scaleX}
                                    onChange={(e) => handleScaleChange('x', e.target.value)}
                                />
                            </div>
                            <div className="input-with-label">
                                <span>Y</span>
                                <input
                                    type="number"
                                    min="0.1"
                                    max="5"
                                    step="0.1"
                                    value={scaleY}
                                    onChange={(e) => handleScaleChange('y', e.target.value)}
                                />
                            </div>
                        </div>
                    </div>

                    {/* Quick Actions */}
                    <div className="quick-actions">
                        <button className="btn btn-secondary" style={{ width: '100%' }}>
                            Duplicate
                        </button>
                        <button className="btn btn-secondary" style={{ width: '100%' }}>
                            Delete
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
}

export default PropertiesPanel;
