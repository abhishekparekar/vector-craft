import { Save, Download, Upload, Grid, ZoomIn, ZoomOut, RotateCcw, FileText } from 'lucide-react';
import './TopBar.css';

function TopBar({ projectName, setProjectName, canvasRef, zoom, gridEnabled, setGridEnabled }) {

    const handleExportSVG = () => {
        if (!canvasRef?.project) return;

        const svg = canvasRef.project.exportSVG({ asString: true });
        const blob = new Blob([svg], { type: 'image/svg+xml' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${projectName}.svg`;
        link.click();
        URL.revokeObjectURL(url);
    };

    const handleExportPNG = () => {
        if (!canvasRef?.view?.element) return;

        const canvas = canvasRef.view.element;
        canvas.toBlob((blob) => {
            const url = URL.createObjectURL(blob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `${projectName}.png`;
            link.click();
            URL.revokeObjectURL(url);
        });
    };

    const handleSaveProject = () => {
        if (!canvasRef?.project) return;

        const json = canvasRef.project.exportJSON();
        const data = {
            name: projectName,
            data: json,
            timestamp: new Date().toISOString()
        };

        localStorage.setItem('vectorcraft_project', JSON.stringify(data));

        // Visual feedback
        const saveBtn = document.querySelector('.save-btn');
        saveBtn.style.background = 'linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)';
        setTimeout(() => {
            saveBtn.style.background = '';
        }, 1000);
    };

    const handleLoadProject = () => {
        const saved = localStorage.getItem('vectorcraft_project');
        if (!saved || !canvasRef?.project) return;

        const data = JSON.parse(saved);
        setProjectName(data.name);
        canvasRef.project.clear();
        canvasRef.project.importJSON(data.data);
    };

    const handleNewProject = () => {
        if (confirm('Create new project? Unsaved changes will be lost.')) {
            canvasRef?.project?.clear();
            setProjectName('Untitled Project');
        }
    };

    return (
        <div className="topbar glass">
            <div className="topbar-left">
                <div className="logo-small">
                    <svg width="32" height="32" viewBox="0 0 80 80">
                        <defs>
                            <linearGradient id="logoSmall" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" stopColor="#667eea" />
                                <stop offset="100%" stopColor="#764ba2" />
                            </linearGradient>
                        </defs>
                        <path d="M20 40 L40 20 L60 40 L40 60 Z" fill="url(#logoSmall)" />
                    </svg>
                </div>

                <input
                    type="text"
                    className="project-name-input"
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    placeholder="Project Name"
                />
            </div>

            <div className="topbar-center">
                <button
                    className="btn-icon tooltip"
                    data-tooltip="New Project"
                    onClick={handleNewProject}
                >
                    <FileText size={18} />
                </button>

                <button
                    className="btn-icon tooltip save-btn"
                    data-tooltip="Save Project"
                    onClick={handleSaveProject}
                >
                    <Save size={18} />
                </button>

                <button
                    className="btn-icon tooltip"
                    data-tooltip="Load Project"
                    onClick={handleLoadProject}
                >
                    <Upload size={18} />
                </button>

                <div className="divider"></div>

                <button
                    className={`btn-icon tooltip ${gridEnabled ? 'active' : ''}`}
                    data-tooltip="Toggle Grid"
                    onClick={() => setGridEnabled(!gridEnabled)}
                >
                    <Grid size={18} />
                </button>

                <div className="zoom-controls">
                    <button className="btn-icon tooltip" data-tooltip="Zoom Out">
                        <ZoomOut size={18} />
                    </button>
                    <span className="zoom-level">{Math.round(zoom * 100)}%</span>
                    <button className="btn-icon tooltip" data-tooltip="Zoom In">
                        <ZoomIn size={18} />
                    </button>
                    <button className="btn-icon tooltip" data-tooltip="Reset View">
                        <RotateCcw size={18} />
                    </button>
                </div>
            </div>

            <div className="topbar-right">
                <button className="btn btn-secondary" onClick={handleExportSVG}>
                    <Download size={16} />
                    SVG
                </button>
                <button className="btn btn-secondary" onClick={handleExportPNG}>
                    <Download size={16} />
                    PNG
                </button>
                <button className="btn btn-primary">
                    <Save size={16} />
                    Save to Cloud
                </button>
            </div>
        </div>
    );
}

export default TopBar;
