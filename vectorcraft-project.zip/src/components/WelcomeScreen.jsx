import { Palette, Layers, Zap, Download, Cloud } from 'lucide-react';
import './WelcomeScreen.css';

function WelcomeScreen({ onStart }) {
    const features = [
        {
            icon: <Palette size={32} />,
            title: 'Vector Drawing',
            description: 'Professional vector tools with precision control'
        },
        {
            icon: <Layers size={32} />,
            title: 'Layer Management',
            description: 'Organize your work with powerful layer system'
        },
        {
            icon: <Zap size={32} />,
            title: 'Real-time Editing',
            description: 'Instant feedback with smooth performance'
        },
        {
            icon: <Download size={32} />,
            title: 'Export Options',
            description: 'Export as SVG, PNG with high quality'
        },
        {
            icon: <Cloud size={32} />,
            title: 'Cloud Save',
            description: 'Save and access your projects anywhere'
        }
    ];

    return (
        <div className="welcome-screen">
            <div className="welcome-particles"></div>

            <div className="welcome-content fade-in">
                <div className="welcome-logo">
                    <div className="logo-icon">
                        <svg width="80" height="80" viewBox="0 0 80 80">
                            <defs>
                                <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                    <stop offset="0%" stopColor="#667eea" />
                                    <stop offset="100%" stopColor="#764ba2" />
                                </linearGradient>
                            </defs>
                            <path
                                d="M20 40 L40 20 L60 40 L40 60 Z M40 10 L70 40 L40 70 L10 40 Z"
                                fill="url(#logoGradient)"
                                opacity="0.8"
                            />
                            <circle cx="40" cy="40" r="8" fill="url(#logoGradient)" />
                        </svg>
                    </div>
                    <h1 className="welcome-title">
                        Vector<span className="text-gradient">Craft</span>
                    </h1>
                </div>

                <p className="welcome-subtitle">
                    Professional web-based vector design tool
                </p>

                <div className="features-grid">
                    {features.map((feature, index) => (
                        <div
                            key={index}
                            className="feature-card glass"
                            style={{ animationDelay: `${index * 0.1}s` }}
                        >
                            <div className="feature-icon">{feature.icon}</div>
                            <h3>{feature.title}</h3>
                            <p>{feature.description}</p>
                        </div>
                    ))}
                </div>

                <button className="btn btn-primary btn-start" onClick={onStart}>
                    <Zap size={20} />
                    Start Creating
                </button>

                <div className="welcome-footer">
                    <p>Built with Paper.js • React • Firebase</p>
                </div>
            </div>
        </div>
    );
}

export default WelcomeScreen;
